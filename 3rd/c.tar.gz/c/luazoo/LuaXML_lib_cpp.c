/* workaround - since MSVC doesn't support C99, compile as C++
   with C linkage */
extern "C" {
#include "LuaXML_lib.c"
}




