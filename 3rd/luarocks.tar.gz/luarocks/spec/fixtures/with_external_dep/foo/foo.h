#define FOO 42
